
#include "quadratic.h"
#include "linear.h"

/**
 * @brief Default constructor
 *
 * @param d the degree of the polynomial
 * @param c the variable of the polynomial
 */
quadratic::quadratic(char c) : univariate(2, c) {
}
/**
 * @brief Parameterized constructor
 *
 * @param t the array of terms
 * @param n the number of terms in the array
 */
quadratic::quadratic(term** t, int n) : univariate(t, n) {
    degree = 2;
    if (numTerms != 0) {
        if (!isUnivariate()) {
            clearTerms();
        }
    }
}
/**
 * @brief Parameterized constructor
 *
 * @param input the string input
 * Format is "a*x^b + c*x^d + ...", where a, b, c, and d are integers.
 */
quadratic::quadratic(const char* input) : univariate(input) {
    degree = 2;
    if (numTerms != 0) {
        if (!isUnivariate()) {
            clearTerms();
        }
    }
}

quadratic::quadratic(const quadratic &other) : univariate(other) {
    degree = 2;
//    if (numTerms != 0) {
//        if (!isUnivariate()) {
//            clearTerms();
//        }
//    }
}

quadratic::quadratic(const polynomial &other) : univariate(other) {
    degree = 2;
    if (numTerms != 0) {
        if (!isUnivariate()) {
            clearTerms();
        }
    }
}

quadratic::quadratic(term t) : univariate(t) {
    degree = 2;
    if (numTerms != 0) {
        if (!isUnivariate()) {
            clearTerms();
        }
    }
}

void quadratic::printRoots() const {
    if (getNumTerms() == 0) {
        std::cout << "No roots" << endl;
        return;
    }
    linear l(*this);
    if (l.getNumTerms() != 0) {
        l.printRoots();
        return;
    }

    double a, b, c;
    a = (*terms[0])[-1];
    b = (*terms[1])[-1];
    c = (*terms[2])[-1];

    double d = b * b - 4 * a * c;

    if (d < 0) {
        std::cout << "No roots" << endl;
        return;
    }

    double r1 = (-b + sqrt(d)) / (2 * a);
    double r2 = (-b - sqrt(d)) / (2 * a);

    std::cout << "Roots : " << terms[0]->getVariables()[0] << " = "
                << std::setprecision(2) << r1 << " , "
                << terms[0]->getVariables()[0] << " = "
                << r2 << endl;
}
